# Exam 2 
# Michael Gain
# 9/26/2020

import sys
from PyQt5.QtWidgets import QDialog, QInputDialog, QApplication
from PyQt5.uic import loadUi
from PyQt5.QtGui import QIcon, QPixmap

class MyForm(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = loadUi("exam3_gain.ui", self)

        self.ui.comboBoxState.currentIndexChanged.connect(self.flagInfo)

        self.states = {
            "AK": ["flags\\ak_fi.gif", "1927", "7 Stars to form the Big Dipper and 1 star to represent the North Star."],
            "AZ": ["flags\\az_fi.gif", "1917", "Copper Star, Red and Yellow Stripes, Blue bottom half."],
            "NC": ["flags\\nc_fi.gif", "1885", "Star, glit scroll, NC, red and white stripes, blue union."],
            "NY": ["flags\\ny_fi.gif", "1778", "Excelsior, Ladies of justice, Eagle"],
            "FL": ["flags\\fl_fi.gif", "1868", "Red X, Gold seal with person flowers palm tree boat sunshine and water."]
        }

        self.flagInfo()

        self.show()


    def flagInfo(self):
        self.state = self.comboBoxState.currentText()
        self.flagPixmap = QPixmap(self.states[self.state][0])
        self.labelImage.setPixmap(self.flagPixmap)
        self.labelYearAdopted.setText(self.states[self.state][1])
        self.labelMajorItems.setText(self.states[self.state][2])


    def exitMethod(self):
        QApplication.instance().quit()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyForm()
    print("Michael Gain end of Exam 3")
    sys.exit(app.exec_())
